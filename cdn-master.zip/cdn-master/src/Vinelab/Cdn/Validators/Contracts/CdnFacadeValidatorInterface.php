<?php

namespace Vinelab\Cdn\Validators\Contracts;

/**
 * Interface CdnFacadeValidatorInterface.
 *
 * @author  Mahmoud Zalt <mahmoud@vinelab.com>
 */
interface CdnFacadeValidatorInterface
{
}
