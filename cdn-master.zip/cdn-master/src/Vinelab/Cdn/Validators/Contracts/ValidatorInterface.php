<?php

namespace Vinelab\Cdn\Validators\Contracts;

/**
 * Interface ValidatorInterface.
 *
 * @author  Mahmoud Zalt <mahmoud@vinelab.com>
 */
interface ValidatorInterface
{
}
