<?php

namespace Vinelab\Cdn\Validators;

use Vinelab\Cdn\Validators\Contracts\ValidatorInterface;

/**
 * Class Validator
 * Main Validator Class.
 *
 * @category Main Validator
 *
 * @author  Mahmoud Zalt <mahmoud@vinelab.com>
 */
class Validator implements ValidatorInterface
{
}
